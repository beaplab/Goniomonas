

sed 's/\-//g' sed 's/\-//g' goniomonads.fasta > goniomonads_nogaps.fasta
sed 's/\_.*//' goniomonads_nogaps.fasta > goniomonads_nogaps_renamed.fasta

/home/dzavadska/eukref_datasets/usearch -sortbylength goniomonads_nogaps_renamed.fasta -fastaout goniomonads_nogaps_renamed.sorted.fasta -minseqlength 500 -notrunclabels
/home/dzavadska/eukref_datasets/usearch -cluster_smallmem goniomonads_nogaps_renamed.sorted.fasta -id 0.97 -centroids goniomonads_nogaps_renamed.clustered.fasta -uc goniomonads_nogaps_renamed.clusters -notrunclabels

sudo python2 eukref_gbretrieve.py -i ../Goniomonas_eukref/goniomonads_nogaps_renamed.clustered.fasta -dbnt /scratch/data1/aauladell/databases/nt/nt_blastdb/nt_blast -dbsi Reference_DB.fas -n 100 -p 32 -g Goniomonadales -m megablast -idsi 75 -idnt 80 -td tax_d.bin

#new putatively goniomonas sequences not present in the input alignment
# EF526832 ==> CRY-4 lineage ALREADY INCLUDED INTO THE OUTGROUP
# EF526920  ==> sister to CRY-4 lineage ==> added to alignment
# EF674349 ==> Goniomonas related to LC683686 clade ==> added to alignment


#MAFFT v7.453 (2019/Nov/8)
"/usr/bin/mafft"  --auto --inputorder "eukref_goniomonads_outgroup.fasta" > "eukref_goniomonads_outgroup_mafft.fasta"
fasttree -nt ./eukref_goniomonads_outgroup_mafft.fasta > ./eukref_goniomonads_outgroup_mafft_fasttree





>AF106051
>AJ564772/1-1829
>AY827844
>DQ222877
>X68483/1-1797
>X70803/1-1816
>X77480/1-1801
>MH107134_Cryptophyceae|Cryptomonadales|lineage-E|Rduplex-clade|strain=rCR01_LOHABE/1-1698
